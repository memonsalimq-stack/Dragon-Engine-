package com.easyvictory.mods;

// Dragon Engine | @Memon_salim
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {

    //Only if you have changed MainActivity to yours and you wanna call game's activity.
    public String GameActivity = "com.miniclip.carrom.CarromActivity";
    public boolean hasLaunched = false;

    //Load lib
    static {
        // Load fixed core prebuilt library first, then public host library
        System.loadLibrary("HwMods");
        System.loadLibrary("Crash");
    }

    private static final int REQ_LICENSE_GATE = 0x4C45;

    //To call onCreate, please refer to README.md
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mandatory Firebase key gate: Start() (mod menu) and the game activity
        // below are only reached after LicenseGateActivity finishes with
        // RESULT_OK. See LicenseGateActivity / FirebaseLicense for the check.
        startActivityForResult(new Intent(this, LicenseGateActivity.class), REQ_LICENSE_GATE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_LICENSE_GATE) return;
        if (resultCode != RESULT_OK) {
            // No valid key: do not start the overlay or the game activity.
            finish();
            return;
        }
        proceedAfterLicense();
    }

    private void proceedAfterLicense() {
        //To launch mod menu.
        Start(this);

        //To launch game activity
        if (!hasLaunched) {
            try {
                //Start service
                MainActivity.this.startActivity(new Intent(MainActivity.this, Class.forName(MainActivity.this.GameActivity)));
                hasLaunched = true;
            } catch (ClassNotFoundException e) {
                //Uncomment this if you are following METHOD 2 of CHANGING FILES
                //Toast.makeText(MainActivity.this, "Error. Game's main activity does not exist", Toast.LENGTH_LONG).show();
                //e.printStackTrace();
                return;
            }
        }
    }

    public static void Start(final Context context) {
        //Check if overlay permission is enabled or not
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
            Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                    Uri.parse("package:" + context.getPackageName())));
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    System.exit(1);
                }
            }, 5000);
            return;
        } else {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    context.startService(new Intent(context, Menu.class));
                }
            }, 500);
        }
    }
}
