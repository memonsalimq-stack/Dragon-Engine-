package com.easyvictory.mods;

import android.animation.ValueAnimator;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.LinearGradient;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.StyleSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Shared Dragon Engine look (black and gold) used by Menu and CrmExternalMenu:
 * palette, icon loading (assets/ev_icons plus vector-style glyphs), header, license strip,
 * tabs, feature rows, switches, footer, settings page and login card.
 * Labels, feature ids and native callbacks are never changed here; this class only presents them.
 */
final class EvIcons {

    static final int BG_DARK = 0xFF1A1B1F;
    static final int BG_DARK_2 = 0xFF1F2024;
    static final int SURFACE = 0xFF25262B;
    static final int ROW_FILL = 0xFF25262B;
    static final int ROW_BORDER = 0xFF383940;
    static final int GOLD = 0xFFFF7A59;
    static final int GOLD_BRIGHT = 0xFFFF7A59;
    static final int GOLD_LIGHT = 0xFFFF9C80;
    static final int GOLD_DEEP = 0xFFE5603F;
    static final int BORDER_GOLD = 0xFFF87858;
    static final int TEXT_WHITE = 0xFFFFFFFF;
    static final int TEXT_MUTED = 0xFFBDBDBD;
    static final int TEXT_SUBTLE = 0xFFBDBDBD;
    static final int TEXT_ON_GOLD = 0xFF101010;
    static final int SWITCH_OFF_THUMB = 0xFF4A4A4A;
    static final int ERROR_RED = 0xFFFF5252;
    static final int GREEN_ONLINE = 0xFF39E75F;
    static final int TG_BLUE = 0xFF29B6F6;

    static final String UI_VERSION = "3.1";
    static final String SUBTITLE_FALLBACK = "CARROM POOL • PREMIUM EDITION";
    static final String CREDIT_FALLBACK = "Created By @Memon_salim";
    // Values supplied by the project owner; used only when the native getters return nothing usable.
    static final String TG_PERSONAL_FALLBACK = "Memon_salim";
    static final String TG_CHANNEL_FALLBACK = "https://t.me/DragonEngineOfficial";

    private EvIcons() {
    }

    static int dp(Context context, int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    static float dpF(Context context, float value) {
        return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    static GradientDrawable cardBackground(Context context, int fillColor, int strokeColor) {
        return cardBackground(context, fillColor, strokeColor, 10f, 1);
    }

    static GradientDrawable cardBackground(
            Context context, int fillColor, int strokeColor, float radiusDp, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fillColor);
        d.setCornerRadius(dp(context, Math.round(radiusDp)));
        if (strokeDp > 0) {
            d.setStroke(dp(context, strokeDp), strokeColor);
        }
        return d;
    }

    static GradientDrawable createMenuPanelBackground(Context ctx) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_DARK, BG_DARK_2});
        drawable.setCornerRadius(dp(ctx, 28));
        drawable.setStroke(dp(ctx, 2), BORDER_GOLD);
        return drawable;
    }

    // ------------------------------------------------------------------
    //  Icons
    // ------------------------------------------------------------------

    /**
     * Returns a glyph (name starts with "glyph_") or decodes a PNG from assets/ev_icons/&lt;name&gt;.png.
     * 128x128 row/tab icon sheets are decoded at XXHIGH density so they scale identically on all screens;
     * the logos and play buttons keep their native pixel size.
     */
    static Drawable evIconRaw(Context ctx, String name) {
        if (ctx == null || name == null || name.isEmpty()) return null;
        int glyph = EvGlyph.kindForName(name);
        if (glyph >= 0) return EvGlyph.create(ctx, glyph, 38);
        try {
            Resources res = ctx.getResources();
            int resId = res.getIdentifier(name, "drawable", ctx.getPackageName());
            if (resId != 0) {
                Drawable d = res.getDrawable(resId);
                if (d != null) return d.mutate();
            }
        } catch (Throwable ignored) { }

        String[] paths = new String[]{"ev_icons/" + name + ".png", name + ".png"};
        for (String path : paths) {
            try (InputStream is = ctx.getAssets().open(path)) {
                DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
                BitmapFactory.Options opts = new BitmapFactory.Options();
                if (!"ev_icon_ev".equals(name)
                        && !"ev_dragon_logo".equals(name)
                        && !"ev_icon_minus".equals(name)
                        && !name.startsWith("ev_play_")) {
                    opts.inDensity = DisplayMetrics.DENSITY_XXHIGH;
                    opts.inTargetDensity = dm.densityDpi;
                    opts.inScaled = true;
                }
                Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
                if (bmp != null) {
                    BitmapDrawable bd = new BitmapDrawable(ctx.getResources(), bmp);
                    return bd;
                }
            } catch (Throwable ignored) { }
        }
        return null;
    }

    static Drawable evIcon(Context ctx, String name, int tint) {
        Drawable d = evIconRaw(ctx, name);
        if (d != null && tint != 0) {
            d = d.mutate();
            d.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
        }
        return d;
    }

    /** Brand emblem: bundled dragon first, then the logo supplied by the native library, then the legacy EV mark. */
    static Drawable brandLogo(Context ctx, String nativeIconBase64) {
        try {
            byte[] png = Base64.decode(EvLogoData.png(), Base64.DEFAULT);
            Bitmap own = BitmapFactory.decodeByteArray(png, 0, png.length);
            if (own != null) return new BitmapDrawable(ctx.getResources(), own);
        } catch (Throwable ignored) { }
        Drawable dragon = evIconRaw(ctx, "ev_dragon_logo");
        if (dragon != null) return dragon;
        if (nativeIconBase64 != null && !nativeIconBase64.isEmpty()) {
            try {
                byte[] decoded = Base64.decode(nativeIconBase64, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                if (bmp != null) return new BitmapDrawable(ctx.getResources(), bmp);
            } catch (Exception ignored) { }
        }
        return evIconRaw(ctx, "ev_icon_ev");
    }

    // ------------------------------------------------------------------
    //  Presentation names (display only; native labels and ids are never changed)
    // ------------------------------------------------------------------

    static String displayTitle(String featName) {
        if (featName == null) return "";
        switch (featName) {
            case "Auto Aim Target": return "Precision Guide";
            case "Clean Table": return "Table Cleaner";
            case "Autoplay": return "Shot Assistant";
            case "Auto Queue": return "Quick Controls";
            default: return featName;
        }
    }

    static String displaySubtitle(String featName) {
        if (featName == null) return "";
        switch (featName) {
            case "Auto Aim Target": return "Auto aim assistance";
            case "Clean Table": return "Remove unwanted coins";
            case "Autoplay": return "Smart shot helper";
            case "Auto Queue": return "Fast play controls";
            case "Show Prediction": return "Preview the shot path";
            case "Highlight Pockets": return "Mark the pockets";
            case "Freeze Shot Lines": return "Hold guide lines in place";
            case "No Ads": return "Skip advertisements";
            default: return "";
        }
    }

    static String rowIconName(String featName) {
        if (featName == null) return "ev_icon_gear";
        String low = featName.toLowerCase(Locale.US);
        if (low.contains("auto") && low.contains("queue")) return "ev_icon_gamepad";
        if (low.contains("colour") || low.contains("color")) return "ev_icon_palette";
        if (low.contains("aim") || low.contains("crosshair")) return "ev_icon_crosshair";
        if (low.contains("autoplay") || low.contains("auto play")) return "ev_icon_bolt";
        if (low.contains("clean")) return "glyph_broom";
        if (low.contains("scanner") || low.contains("depth")) return "ev_icon_search";
        if (low.contains("force") || low.contains("power")) return "ev_icon_bolt";
        if (low.contains("cushion")) return "ev_icon_gear";
        if (low.contains("prediction")) return "ev_icon_dots";
        if (low.contains("pocket") || low.contains("highlight")) return "ev_icon_target";
        if (low.contains("freeze") || low.contains("line")) return "ev_icon_percent";
        if (low.contains("price") || low.contains("table")) return "ev_icon_coins";
        if (low.contains("game") || low.contains("mode")) return "ev_icon_gamepad";
        return "ev_icon_gear";
    }

    static String tabIconName(String title) {
        if (title == null) return "ev_icon_grid";
        String low = title.toLowerCase(Locale.US);
        if (low.equals("aim")) return "ev_icon_crosshair";
        if (low.equals("tools")) return "ev_icon_gear";
        if (low.equals("settings")) return "glyph_sliders";
        if (low.contains("visual") || low.contains("vision")) return "ev_icon_eye";
        if (low.contains("play")) return "ev_icon_gamepad";
        if (low.contains("queue")) return "ev_icon_queue";
        return "ev_icon_grid";
    }

    static void applyRowIcon(Context ctx, TextView view, String featName) {
        Drawable d = evIcon(ctx, rowIconName(featName), GOLD);
        if (d != null) {
            view.setCompoundDrawablesWithIntrinsicBounds(d, null, null, null);
            view.setCompoundDrawablePadding(dp(ctx, 12));
        }
    }

    /** Two-line row text: bold white title with an optional muted subtitle. */
    static CharSequence rowText(Context ctx, String featName) {
        String title = displayTitle(featName);
        String sub = displaySubtitle(featName);
        SpannableStringBuilder sb = new SpannableStringBuilder(title);
        sb.setSpan(new ForegroundColorSpan(TEXT_WHITE), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new AbsoluteSizeSpan(15, true), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new StyleSpan(Typeface.BOLD), 0, title.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (!sub.isEmpty()) {
            sb.append("\n");
            int start = sb.length();
            sb.append(sub);
            sb.setSpan(new ForegroundColorSpan(TEXT_MUTED), start, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new AbsoluteSizeSpan(12, true), start, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sb;
    }

    // ------------------------------------------------------------------
    //  Header (emblem, wordmark, subtitle, status, minimize and close)
    // ------------------------------------------------------------------

    static final class HeaderViews {
        LinearLayout root;
        ImageView logo;
        TextView statusText;
        View statusDot;
        ImageView minimizeButton;
        ImageView closeButton;
    }

    static final class LicenseViews {
        LinearLayout root;
        TextView title;
        TextView expiry;
    }

    static HeaderViews createHeader(
            final Context ctx, String nativeIconBase64, String modTitle, String subtitle,
            View.OnClickListener onMinimize, View.OnLongClickListener onHide, final Runnable onClose) {
        final String title = (modTitle != null && !modTitle.trim().isEmpty()) ? modTitle.trim() : "DRAGON ENGINE";
        HeaderViews out = new HeaderViews();

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        out.root = root;

        FrameLayout top = new FrameLayout(ctx);
        top.setPadding(0, dp(ctx, 12), 0, dp(ctx, 4));

        LinearLayout brand = new LinearLayout(ctx);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(dp(ctx, 16), 0, 0, 0);

        ImageView logo = new ImageView(ctx);
        Drawable emblem = brandLogo(ctx, nativeIconBase64);
        if (emblem != null) logo.setImageDrawable(emblem);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription(title + " logo. Drag to move.");
        brand.addView(logo, new LinearLayout.LayoutParams(dp(ctx, 78), dp(ctx, 72)));
        out.logo = logo;

        LinearLayout words = new LinearLayout(ctx);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setPadding(dp(ctx, 6), 0, 0, 0);
        String first = title;
        String second = "";
        int space = title.indexOf(' ');
        if (space > 0) {
            first = title.substring(0, space);
            second = title.substring(space + 1).trim();
        }
        words.addView(wordmark(ctx, first, new int[]{0xFFFF9C80, 0xFFFF7A59, 0xFFE5603F}));
        if (!second.isEmpty()) {
            words.addView(wordmark(ctx, second, new int[]{0xFFFFFFFF, 0xFFD6D6D6, 0xFF8E8E8E}));
        }
        brand.addView(words, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        top.addView(brand, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout controls = new LinearLayout(ctx);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        final ImageView minimize = headerControl(ctx, "glyph_minus", "Minimize menu. Hold to hide icon.");
        if (onMinimize != null) minimize.setOnClickListener(onMinimize);
        if (onHide != null) minimize.setOnLongClickListener(onHide);
        final ImageView close = headerControl(ctx, "glyph_close", "Close menu");
        controls.addView(minimize, controlParams(ctx, 6));
        controls.addView(close, controlParams(ctx, 0));
        FrameLayout.LayoutParams controlsLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        controlsLp.rightMargin = dp(ctx, 12);
        top.addView(controls, controlsLp);
        out.minimizeButton = minimize;
        out.closeButton = close;

        // Closing needs two taps within 2.5 seconds so a stray touch cannot dismiss the menu.
        final boolean[] armed = new boolean[1];
        final Runnable disarm = new Runnable() {
            @Override public void run() {
                armed[0] = false;
                close.setBackground(cardBackground(ctx, ROW_FILL, ROW_BORDER, 10f, 1));
                close.setContentDescription("Close menu");
            }
        };
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (armed[0]) {
                    v.removeCallbacks(disarm);
                    armed[0] = false;
                    if (onClose != null) onClose.run();
                    return;
                }
                armed[0] = true;
                close.setBackground(cardBackground(ctx, 0xFF3A1212, ERROR_RED, 10f, 1));
                close.setContentDescription("Tap again to close");
                Toast.makeText(ctx, "Tap X again to close", Toast.LENGTH_SHORT).show();
                v.postDelayed(disarm, 2500);
            }
        });
        root.addView(top);

        String sub = normalizeSubtitle(subtitle);
        root.addView(ruleRow(ctx, sub, GOLD_LIGHT, 11f, Typeface.BOLD_ITALIC, 0.04f, 2, 0));

        LinearLayout statusRow = ruleRow(ctx, "SYSTEM ONLINE", GREEN_ONLINE, 13f, Typeface.BOLD, 0.08f, 4, 8);
        TextView statusText = (TextView) statusRow.getChildAt(1);
        statusText.setShadowLayer(8f, 0, 0, 0x6639E75F);
        final View dot = new View(ctx);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(GREEN_ONLINE);
        dot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(ctx, 9), dp(ctx, 9));
        dotLp.rightMargin = dp(ctx, 7);
        // The row is rule, text, rule; the dot goes between the first rule and the text.
        statusRow.addView(dot, 1, dotLp);
        final ValueAnimator pulse = ValueAnimator.ofFloat(1.0f, 0.35f, 1.0f);
        pulse.setDuration(1800);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator animation) {
                dot.setAlpha((Float) animation.getAnimatedValue());
            }
        });
        statusRow.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { pulse.start(); }
            @Override public void onViewDetachedFromWindow(View v) { pulse.cancel(); }
        });
        root.addView(statusRow);
        out.statusText = statusText;
        out.statusDot = dot;
        return out;
    }

    private static TextView wordmark(Context ctx, String text, int[] gradient) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        float sizeSp = 27f;
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv.setTextColor(gradient[1]);
        tv.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC));
        tv.setIncludeFontPadding(false);
        tv.setSingleLine(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tv.setLetterSpacing(0.02f);
        }
        float heightPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp * 1.1f,
                ctx.getResources().getDisplayMetrics());
        tv.getPaint().setShader(new LinearGradient(0, 0, 0, heightPx, gradient, null, Shader.TileMode.CLAMP));
        return tv;
    }

    private static ImageView headerControl(Context ctx, String glyph, String description) {
        ImageView button = new ImageView(ctx);
        button.setImageDrawable(evIcon(ctx, glyph, TEXT_WHITE));
        button.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = dp(ctx, 8);
        button.setPadding(pad, pad, pad, pad);
        button.setBackground(cardBackground(ctx, ROW_FILL, ROW_BORDER, 10f, 1));
        button.setContentDescription(description);
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private static LinearLayout.LayoutParams controlParams(Context ctx, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(ctx, 34), dp(ctx, 34));
        lp.rightMargin = dp(ctx, rightMarginDp);
        return lp;
    }

    private static String normalizeSubtitle(String raw) {
        if (raw == null || raw.trim().isEmpty()) return SUBTITLE_FALLBACK;
        return raw.replace("|", "•").replaceAll("\\s+", " ").trim();
    }

    /** Fading gold rule, used on both sides of centered captions. */
    private static View rule(Context ctx, boolean fadeIn) {
        View v = new View(ctx);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                fadeIn ? new int[]{0x00FF7A59, 0xFFFF7A59} : new int[]{0xFFFF7A59, 0x00FF7A59});
        v.setBackground(g);
        return v;
    }

    /** [rule] caption [rule]. Child 0 and 2 are the rules and child 1 is replaced by the caption. */
    private static LinearLayout ruleRow(Context ctx, String caption, int color, float sizeSp,
                                        int style, float spacing, int topPadDp, int bottomPadDp) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(ctx, 12), dp(ctx, topPadDp), dp(ctx, 12), dp(ctx, bottomPadDp));
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, dp(ctx, 1), 1f);
        left.rightMargin = dp(ctx, 8);
        row.addView(rule(ctx, true), left);
        TextView tv = new TextView(ctx);
        tv.setText(caption);
        tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tv.setLetterSpacing(spacing);
        }
        row.addView(tv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, dp(ctx, 1), 1f);
        right.leftMargin = dp(ctx, 8);
        row.addView(rule(ctx, false), right);
        return row;
    }

    // ------------------------------------------------------------------
    //  License strip with the two Telegram buttons
    // ------------------------------------------------------------------

    static String personalHandle(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.startsWith("@")) s = s.substring(1);
        return s.matches("[A-Za-z0-9_]{5,32}") ? s : TG_PERSONAL_FALLBACK;
    }

    static String channelUrl(String raw) {
        String s = raw == null ? "" : raw.trim();
        return (s.startsWith("https://t.me/") && s.length() > "https://t.me/".length()) ? s : TG_CHANNEL_FALLBACK;
    }

    static LicenseViews createLicenseStrip(final Context ctx, String handleRaw, String channelRaw) {
        final String handle = personalHandle(handleRaw);
        final String channel = channelUrl(channelRaw);
        LicenseViews out = new LicenseViews();

        LinearLayout strip = new LinearLayout(ctx);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 8), dp(ctx, 8));
        strip.setBackground(cardBackground(ctx, ROW_FILL, BORDER_GOLD, 14f, 1));
        LinearLayout.LayoutParams stripLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stripLp.setMargins(dp(ctx, 12), dp(ctx, 2), dp(ctx, 12), dp(ctx, 8));
        strip.setLayoutParams(stripLp);
        out.root = strip;

        LinearLayout left = new LinearLayout(ctx);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        ImageView shield = new ImageView(ctx);
        shield.setImageDrawable(evIcon(ctx, "glyph_shield", GOLD));
        shield.setScaleType(ImageView.ScaleType.FIT_CENTER);
        left.addView(shield, new LinearLayout.LayoutParams(dp(ctx, 30), dp(ctx, 30)));

        LinearLayout texts = new LinearLayout(ctx);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(ctx, 8), 0, dp(ctx, 4), 0);
        TextView title = new TextView(ctx);
        title.setText("LICENSE REQUIRED");
        title.setTextColor(GOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(title);
        TextView expiry = new TextView(ctx);
        expiry.setText("Sign in with your key");
        expiry.setTextColor(TEXT_WHITE);
        expiry.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        expiry.setSingleLine(true);
        expiry.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(expiry);
        left.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        strip.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        out.title = title;
        out.expiry = expiry;

        View divider = new View(ctx);
        divider.setBackgroundColor(0x66FF7A59);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(dp(ctx, 1), dp(ctx, 46));
        divLp.setMargins(dp(ctx, 4), 0, dp(ctx, 8), 0);
        strip.addView(divider, divLp);

        LinearLayout right = new LinearLayout(ctx);
        right.setOrientation(LinearLayout.VERTICAL);
        LinearLayout personal = telegramButton(ctx, "@" + handle, 11f);
        personal.setContentDescription("Open personal Telegram @" + handle);
        personal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternalUrl(ctx, "https://t.me/" + handle); }
        });
        LinearLayout channelBtn = telegramButton(ctx, "Join Channel", 11f);
        channelBtn.setContentDescription("Open Telegram channel");
        channelBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternalUrl(ctx, channel); }
        });
        right.addView(personal, new LinearLayout.LayoutParams(dp(ctx, 118), dp(ctx, 28)));
        LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(dp(ctx, 118), dp(ctx, 28));
        chLp.topMargin = dp(ctx, 5);
        right.addView(channelBtn, chLp);
        strip.addView(right, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return out;
    }

    /** Rounded Telegram button: blue paper-plane glyph plus a short gold label. */
    private static LinearLayout telegramButton(Context ctx, String label, float textSp) {
        LinearLayout button = new LinearLayout(ctx);
        button.setOrientation(LinearLayout.HORIZONTAL);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(ctx, 6), 0, dp(ctx, 6), 0);
        button.setBackground(cardBackground(ctx, 0xFF1A1A1A, BORDER_GOLD, 10f, 1));
        button.setClickable(true);
        button.setFocusable(true);
        ImageView plane = new ImageView(ctx);
        plane.setImageDrawable(evIcon(ctx, "glyph_plane", TG_BLUE));
        plane.setScaleType(ImageView.ScaleType.FIT_CENTER);
        button.addView(plane, new LinearLayout.LayoutParams(dp(ctx, 14), dp(ctx, 14)));
        TextView text = new TextView(ctx);
        text.setText(label);
        text.setTextColor(GOLD);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp);
        text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setSingleLine(true);
        text.setEllipsize(TextUtils.TruncateAt.END);
        text.setPadding(dp(ctx, 5), 0, 0, 0);
        button.addView(text, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        applyButtonTouchEffect(button);
        return button;
    }

    /** Updates the license strip and the status line from live native state. */
    static void applyLicenseState(HeaderViews header, LicenseViews license, boolean signedIn, String rawExpiry) {
        boolean[] expired = new boolean[1];
        String line = signedIn ? formatExpiresLine(rawExpiry, expired) : "Sign in with your key";
        String title;
        int color;
        if (!signedIn) {
            title = "LICENSE REQUIRED";
            color = GOLD;
        } else if (expired[0]) {
            title = "LICENSE EXPIRED";
            color = ERROR_RED;
        } else {
            title = "LICENSE ACTIVE";
            color = GREEN_ONLINE;
        }
        if (license != null) {
            license.title.setText(title);
            license.title.setTextColor(color);
            license.expiry.setText(line);
        }
        if (header != null) {
            String status = !signedIn ? "AWAITING LOGIN" : (expired[0] ? "LICENSE EXPIRED" : "SYSTEM ONLINE");
            header.statusText.setText(status);
            header.statusText.setTextColor(color);
            header.statusText.setShadowLayer(8f, 0, 0, (color & 0x00FFFFFF) | 0x66000000);
            if (header.statusDot.getBackground() instanceof GradientDrawable) {
                ((GradientDrawable) header.statusDot.getBackground()).setColor(color);
            }
        }
    }

    static String formatExpiresLine(String rawExp, boolean[] outExpired) {
        if (outExpired != null && outExpired.length > 0) outExpired[0] = false;
        if (rawExp == null || rawExp.trim().isEmpty()) {
            return "Expires: Active";
        }
        String trimmed = rawExp.trim();
        if (trimmed.equalsIgnoreCase("Lifetime")) {
            return "Expires: Lifetime";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            Date target = sdf.parse(trimmed);
            if (target != null) {
                long diff = target.getTime() - System.currentTimeMillis();
                if (diff <= 0) {
                    if (outExpired != null && outExpired.length > 0) outExpired[0] = true;
                    return "Expired";
                }
                long min = (diff / (1000 * 60)) % 60;
                long hrs = (diff / (1000 * 60 * 60)) % 24;
                long days = diff / (1000 * 60 * 60 * 24);
                if (days > 0) {
                    return "Expires: " + days + (days == 1 ? " day" : " days");
                }
                return String.format(Locale.US, "Expires: %02dh %02dm", hrs, min);
            }
        } catch (Exception ignored) { }
        return "Expires: " + trimmed;
    }

    // ------------------------------------------------------------------
    //  Footer
    // ------------------------------------------------------------------

    static LinearLayout createBrandFooter(Context ctx, String modTitle, String credit) {
        String title = (modTitle != null && !modTitle.trim().isEmpty()) ? modTitle.trim() : "DRAGON ENGINE";
        String creditText = (credit != null && !credit.trim().isEmpty()) ? credit.trim() : CREDIT_FALLBACK;
        LinearLayout footer = new LinearLayout(ctx);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(0, dp(ctx, 8), 0, dp(ctx, 10));
        float r = dpF(ctx, 26);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1A1405, 0xFF0F0B03});
        bg.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        footer.setBackground(bg);

        View topLine = new View(ctx);
        topLine.setBackgroundColor(BORDER_GOLD);
        footer.addView(topLine, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1)));
        // Move the first line of text away from the rule.
        LinearLayout line = ruleRow(ctx, title + " • v" + UI_VERSION, GOLD, 12f, Typeface.BOLD, 0.04f, 8, 2);
        footer.addView(line);

        TextView creditView = new TextView(ctx);
        creditView.setText(creditText);
        creditView.setTextColor(TEXT_WHITE);
        creditView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        creditView.setGravity(Gravity.CENTER);
        footer.addView(creditView);
        return footer;
    }

    // Legacy footer with the minimize square. The new layout minimizes from the header; kept for callers that still want it.
    static FrameLayout createMinimizeFooter(
            Context ctx, View.OnClickListener onMinimize, View.OnLongClickListener onHide) {
        FrameLayout footer = new FrameLayout(ctx);
        footer.setPadding(10, 3, 10, dp(ctx, 6));

        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);

        Button minBtn = new Button(ctx);
        minBtn.setLayoutParams(btnLp);
        minBtn.setBackground(null);
        minBtn.setText("");
        minBtn.setAllCaps(false);
        minBtn.setMinWidth(0);
        minBtn.setMinimumWidth(0);
        minBtn.setPadding(0, 0, 0, 0);
        Drawable minus = evIcon(ctx, "ev_icon_minus", 0);
        if (minus != null) {
            minus.setBounds(0, 0, dp(ctx, 34), dp(ctx, 34));
            minBtn.setCompoundDrawables(null, minus, null, null);
        }
        minBtn.setMinHeight(dp(ctx, 40));
        minBtn.setContentDescription("Minimize menu. Hold to hide icon.");
        if (onMinimize != null) minBtn.setOnClickListener(onMinimize);
        if (onHide != null) minBtn.setOnLongClickListener(onHide);

        footer.addView(minBtn);
        return footer;
    }

    static void applyQueueButtonStyle(Context context, Button button, boolean autoplayActive) {
        if (button == null || context == null) return;
        Drawable bg = evIcon(context, autoplayActive ? "ev_play_on" : "ev_play_off", 0);
        if (bg != null) {
            button.setBackground(bg);
        }
        button.setContentDescription(autoplayActive ? "Stop Auto Play" : "Auto Play");
    }

    // ------------------------------------------------------------------
    //  Tabs
    // ------------------------------------------------------------------

    static Button createTabButton(Context ctx, String title, boolean selected) {
        Button tab = new Button(ctx);
        tab.setContentDescription(title + " features");
        tab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.0f);
        tab.setAllCaps(false);
        tab.setSingleLine(true);
        tab.setGravity(Gravity.CENTER);
        tab.setMinWidth(0);
        tab.setMinimumWidth(0);
        tab.setMinHeight(0);
        tab.setMinimumHeight(0);
        tab.setPadding(dp(ctx, 3), 0, dp(ctx, 3), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(ctx, 44), 1.0f);
        lp.setMargins(dp(ctx, 3), 0, dp(ctx, 3), 0);
        tab.setLayoutParams(lp);
        tab.setTag(new String[]{tabIconName(title), title});
        styleTabButton(ctx, tab, selected);
        return tab;
    }

    static void styleTabButton(Context ctx, Button tab, boolean selected) {
        if (tab == null) return;
        int textColor = selected ? TEXT_ON_GOLD : 0xFFD0D0D0;
        tab.setTextColor(textColor);
        tab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        if (selected) {
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{GOLD_LIGHT, GOLD_DEEP});
            bg.setCornerRadius(dp(ctx, 12));
            bg.setStroke(dp(ctx, 1), GOLD);
            tab.setBackground(bg);
        } else {
            tab.setBackground(cardBackground(ctx, 0xFF0F0F0F, 0xFF2A2A2A, 12f, 1));
        }
        Object tag = tab.getTag();
        if (tag instanceof String[]) {
            String[] info = (String[]) tag;
            // The icon is an inline span so the icon and the label stay centered together.
            SpannableStringBuilder label = new SpannableStringBuilder();
            Drawable icon = evIcon(ctx, info[0], textColor);
            if (icon != null) {
                int size = dp(ctx, 16);
                icon.setBounds(0, 0, size, size);
                label.append(" ");
                label.setSpan(new ImageSpan(icon, ImageSpan.ALIGN_BOTTOM), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                label.append("  ");
            }
            label.append(info[1]);
            tab.setText(label);
        }
        tab.setSelected(selected);
    }

    // ------------------------------------------------------------------
    //  Feature rows
    // ------------------------------------------------------------------

    static void styleFeatureCard(Context ctx, View card, int minHeightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(ctx, 4), 0, dp(ctx, 4));
        card.setLayoutParams(lp);
        card.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
        card.setBackground(cardBackground(ctx, ROW_FILL, ROW_BORDER, 14f, 1));
        card.setMinimumHeight(dp(ctx, minHeightDp > 0 ? minHeightDp : 52));
    }

    /** Gold pill track with a white knob when on, grey when off. Drawn in code so it works on API 19+. */
    static void styleSwitchWidget(Context ctx, Switch toggle) {
        StateListDrawable track = new StateListDrawable();
        track.addState(new int[]{android.R.attr.state_checked}, switchTrack(ctx, GOLD, GOLD_DEEP));
        track.addState(new int[]{}, switchTrack(ctx, 0xFF3C3C3C, 0xFF555555));
        StateListDrawable thumb = new StateListDrawable();
        thumb.addState(new int[]{android.R.attr.state_checked}, switchThumb(ctx, 0xFFFFFFFF, GOLD));
        thumb.addState(new int[]{}, switchThumb(ctx, 0xFFD9D9D9, 0xFF3C3C3C));
        toggle.setTrackDrawable(track);
        toggle.setThumbDrawable(thumb);
    }

    private static GradientDrawable switchTrack(Context ctx, int fill, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setCornerRadius(dp(ctx, 14));
        d.setColor(fill);
        d.setStroke(dp(ctx, 1), border);
        d.setSize(dp(ctx, 54), dp(ctx, 28));
        return d;
    }

    // The ring has the track color, so the knob looks inset on every API level.
    private static GradientDrawable switchThumb(Context ctx, int fill, int ring) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        d.setStroke(dp(ctx, 4), ring);
        d.setSize(dp(ctx, 28), dp(ctx, 28));
        return d;
    }

    static void styleSwitchCard(Context ctx, Switch toggle, String featName) {
        styleFeatureCard(ctx, toggle, 64);
        toggle.setSwitchPadding(dp(ctx, 10));
        toggle.setGravity(Gravity.CENTER_VERTICAL);
        toggle.setContentDescription(displayTitle(featName));
        toggle.setText(rowText(ctx, featName));
        toggle.setTextColor(TEXT_WHITE);
        applyRowIcon(ctx, toggle, featName);
        styleSwitchWidget(ctx, toggle);
    }

    /** Icon plus two-line title for cards whose control sits underneath (dropdowns, sliders). */
    static LinearLayout createRowHeader(Context ctx, String featName) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Drawable icon = evIcon(ctx, rowIconName(featName), GOLD);
        if (icon != null) {
            ImageView iv = new ImageView(ctx);
            iv.setImageDrawable(icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(iv, new LinearLayout.LayoutParams(dp(ctx, 40), dp(ctx, 40)));
        }
        TextView text = new TextView(ctx);
        text.setText(rowText(ctx, featName));
        text.setPadding(dp(ctx, 12), 0, 0, 0);
        row.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    static void styleSeekLabel(Context ctx, TextView label, String featName) {
        label.setTextColor(TEXT_WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER_VERTICAL);
        applyRowIcon(ctx, label, featName);
    }

    static void styleStatusCard(Context ctx, TextView status) {
        status.setTextColor(TEXT_MUTED);
        status.setTextSize(12.0f);
        status.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        status.setBackground(cardBackground(ctx, ROW_FILL, ROW_BORDER, 14f, 1));
    }

    static void styleRichHint(Context ctx, TextView label) {
        label.setTextColor(TEXT_MUTED);
        label.setTextSize(12.0f);
        label.setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 8), dp(ctx, 12));
    }

    /** Small caps caption that introduces a group of rows. */
    static TextView createSectionLabel(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(0xFFFF7A59);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tv.setLetterSpacing(0.12f);
        }
        tv.setPadding(dp(ctx, 4), dp(ctx, 6), 0, dp(ctx, 2));
        return tv;
    }

    static Button createChoiceButton(Context ctx) {
        Button button = new Button(ctx);
        button.setAllCaps(false);
        button.setTextSize(11.0f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(ctx, 3), dp(ctx, 3), dp(ctx, 3), dp(ctx, 3));
        button.setMinHeight(dp(ctx, 28));
        button.setMinimumHeight(dp(ctx, 28));
        return button;
    }

    static LinearLayout.LayoutParams createChoiceButtonParams(Context ctx) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(ctx, 28), 1.0f);
        lp.setMargins(dp(ctx, 2), dp(ctx, 2), dp(ctx, 2), dp(ctx, 2));
        return lp;
    }

    static void styleChoiceButton(Context ctx, Button button, boolean active, int customAccent,
                                  String itemText, String accessiblePrefix) {
        int accent = customAccent != 0 ? customAccent : GOLD;
        int border = customAccent != 0 ? customAccent : BORDER_GOLD;
        int unselectedText = customAccent != 0 ? customAccent : GOLD;
        button.setSelected(active);
        button.setText((active ? "✓  " : "") + itemText);
        button.setTextColor(active ? BG_DARK : unselectedText);
        button.setBackground(cardBackground(ctx, active ? accent : BG_DARK, active ? accent : border, 10f, 1));
        button.setContentDescription(accessiblePrefix + ": " + itemText + (active ? ", selected" : ", not selected"));
    }

    static ArrayAdapter<String> createSpinnerAdapter(final Context ctx, final List<String> items) {
        return new ArrayAdapter<String>(ctx, android.R.layout.simple_spinner_item, items) {
            private View buildRow(int position, boolean dropdown) {
                TextView text = new TextView(ctx);
                text.setText(getItem(position));
                text.setTextColor(GOLD);
                text.setTextSize(12.0f);
                text.setGravity(Gravity.CENTER_VERTICAL);
                text.setMinHeight(dp(ctx, 30));
                text.setPadding(dp(ctx, 4), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
                if (dropdown) {
                    text.setBackgroundColor(SURFACE);
                }
                return text;
            }

            @Override public View getView(int p, View v, ViewGroup parent) { return buildRow(p, false); }
            @Override public View getDropDownView(int p, View v, ViewGroup parent) { return buildRow(p, true); }
        };
    }

    static void attachSpinner(Context ctx, LinearLayout card, Spinner spinner) {
        spinner.setMinimumHeight(dp(ctx, 30));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(ctx, 6);
        spinner.setLayoutParams(lp);
        if (spinner.getBackground() != null) {
            spinner.getBackground().setColorFilter(TEXT_MUTED, PorterDuff.Mode.SRC_ATOP);
        }
        spinner.setPopupBackgroundDrawable(cardBackground(ctx, SURFACE, BORDER_GOLD, 10f, 1));
        card.addView(spinner);
    }

    static void styleSeekBar(Context context, SeekBar seekBar) {
        if (seekBar == null) return;
        seekBar.setMinimumHeight(dp(context, 34));
        int p = dp(context, 8);
        seekBar.setPadding(p, p, p, p);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressTintList(ColorStateList.valueOf(GOLD));
            seekBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF3A3A3A));
            seekBar.setThumbTintList(ColorStateList.valueOf(GOLD));
        } else {
            if (seekBar.getThumb() != null) {
                seekBar.getThumb().setColorFilter(GOLD, PorterDuff.Mode.SRC_ATOP);
            }
            if (seekBar.getProgressDrawable() != null) {
                seekBar.getProgressDrawable().setColorFilter(GOLD, PorterDuff.Mode.SRC_ATOP);
            }
        }
    }

    static String formatSeekBarLabel(String featName, int value, int defaultVal) {
        String formatted;
        String suffix = "";
        if (featName.contains("Speed Scale")) {
            formatted = String.format(Locale.US, "%.1fx", value / 10.0f);
        } else if (featName.contains("Float Brake Button Size")) {
            formatted = String.valueOf(value);
            suffix = " dp";
        } else if (featName.contains("Camera FOV")) {
            formatted = String.valueOf(value);
            suffix = "°";
        } else if (featName.contains("Table Position") || featName.contains("Table Left-Right")
                || featName.contains("Table Up-Down") || featName.contains("Table Vertical Position")) {
            int offset = (int) ((value - 50) * 2.5f);
            formatted = offset > 0 ? "+" + offset : String.valueOf(offset);
            suffix = " px";
        } else if (featName.contains("Table Size") || featName.contains("Bada - Chota")
                || featName.contains("Table Scale Zoom") || featName.contains("Table Width Stretch")) {
            formatted = String.valueOf(value);
            suffix = "%";
        } else if (featName.contains("Goti Circle Size")) {
            formatted = String.valueOf(value);
            suffix = " px";
        } else if (featName.contains("Speed Limit")) {
            formatted = String.valueOf(value);
        } else {
            formatted = String.valueOf(value);
        }
        return featName + ": " + formatted + suffix + (value == defaultVal ? " (Default)" : "");
    }

    static void applyButtonTouchEffect(View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160)
                        .setInterpolator(new OvershootInterpolator(2.2f)).start();
            }
            return false;
        });
    }

    static void openExternalUrl(Context ctx, String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(ctx, "Cannot open link", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    //  SETTINGS tab
    // ------------------------------------------------------------------

    /**
     * Builds the SETTINGS page: floating icon opacity, both Telegram links, optional license purchase
     * link and an about card. The caller owns persistence of the opacity value through {@code opacityListener}.
     */
    static LinearLayout createSettingsPage(
            final Context ctx, int opacityPercent, final SeekBar.OnSeekBarChangeListener opacityListener,
            String handleRaw, String channelRaw, final String buyUrl, String credit) {
        final String handle = personalHandle(handleRaw);
        final String channel = channelUrl(channelRaw);
        LinearLayout page = new LinearLayout(ctx);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(ctx, 8), dp(ctx, 2), dp(ctx, 8), dp(ctx, 8));

        page.addView(createSectionLabel(ctx, "APPEARANCE"));
        LinearLayout opacityCard = new LinearLayout(ctx);
        opacityCard.setOrientation(LinearLayout.VERTICAL);
        styleFeatureCard(ctx, opacityCard, 64);
        final TextView label = new TextView(ctx);
        final int initial = Math.max(10, Math.min(100, opacityPercent));
        label.setText("Floating icon opacity: " + initial + "%");
        label.setTextColor(TEXT_WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER_VERTICAL);
        Drawable sliders = evIcon(ctx, "glyph_sliders", GOLD);
        if (sliders != null) {
            label.setCompoundDrawablesWithIntrinsicBounds(sliders, null, null, null);
            label.setCompoundDrawablePadding(dp(ctx, 12));
        }
        opacityCard.addView(label);
        SeekBar bar = new SeekBar(ctx);
        bar.setMax(90);
        bar.setProgress(initial - 10);
        bar.setContentDescription("Floating icon opacity");
        styleSeekBar(ctx, bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                label.setText("Floating icon opacity: " + (value + 10) + "%");
                if (opacityListener != null) opacityListener.onProgressChanged(seekBar, value, fromUser);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                if (opacityListener != null) opacityListener.onStartTrackingTouch(seekBar);
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (opacityListener != null) opacityListener.onStopTrackingTouch(seekBar);
            }
        });
        opacityCard.addView(bar);
        page.addView(opacityCard);

        page.addView(createSectionLabel(ctx, "COMMUNITY"));
        LinearLayout personal = telegramButton(ctx, "Personal Telegram  @" + handle, 13f);
        personal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternalUrl(ctx, "https://t.me/" + handle); }
        });
        page.addView(personal, wideButtonParams(ctx));
        LinearLayout channelBtn = telegramButton(ctx, "Telegram Channel", 13f);
        channelBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternalUrl(ctx, channel); }
        });
        page.addView(channelBtn, wideButtonParams(ctx));

        if (buyUrl != null && !buyUrl.trim().isEmpty()) {
            Button buy = createLoginActionButton(ctx, "BUY / RENEW LICENSE", true);
            buy.setTextColor(TEXT_ON_GOLD);
            buy.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openExternalUrl(ctx, buyUrl.trim()); }
            });
            page.addView(buy, wideButtonParams(ctx));
        }

        page.addView(createSectionLabel(ctx, "ABOUT"));
        LinearLayout about = new LinearLayout(ctx);
        about.setOrientation(LinearLayout.VERTICAL);
        about.setGravity(Gravity.CENTER_HORIZONTAL);
        styleFeatureCard(ctx, about, 64);
        TextView name = new TextView(ctx);
        name.setText("DRAGON ENGINE • v" + UI_VERSION);
        name.setTextColor(GOLD);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        about.addView(name);
        TextView edition = new TextView(ctx);
        edition.setText(SUBTITLE_FALLBACK);
        edition.setTextColor(TEXT_MUTED);
        edition.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        edition.setGravity(Gravity.CENTER);
        about.addView(edition);
        TextView by = new TextView(ctx);
        by.setText((credit != null && !credit.trim().isEmpty()) ? credit.trim() : CREDIT_FALLBACK);
        by.setTextColor(TEXT_WHITE);
        by.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        by.setGravity(Gravity.CENTER);
        about.addView(by);
        page.addView(about);
        return page;
    }

    /**
     * ABOUT tab: license info for the key that passed the Firebase gate, plus the
     * Telegram channel. All values are plain strings handed in by the caller
     * (LicenseSession / FirebaseLicense); this method only lays them out.
     */
    static LinearLayout createAboutPage(final Context ctx, String channelRaw,
            String adminName, String expiryText, String deviceText) {
        final String channel = channelUrl(channelRaw);
        LinearLayout page = new LinearLayout(ctx);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(ctx, 8), dp(ctx, 2), dp(ctx, 8), dp(ctx, 8));

        page.addView(createSectionLabel(ctx, "DRAGON ENGINE"));
        LinearLayout brand = new LinearLayout(ctx);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        styleFeatureCard(ctx, brand, 56);
        TextView name = new TextView(ctx);
        name.setText("DRAGON ENGINE • v" + UI_VERSION);
        name.setTextColor(GOLD);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        brand.addView(name);
        TextView edition = new TextView(ctx);
        edition.setText(SUBTITLE_FALLBACK);
        edition.setTextColor(TEXT_MUTED);
        edition.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        edition.setGravity(Gravity.CENTER);
        brand.addView(edition);
        page.addView(brand);

        page.addView(createSectionLabel(ctx, "LICENSE"));
        LinearLayout license = new LinearLayout(ctx);
        license.setOrientation(LinearLayout.VERTICAL);
        styleFeatureCard(ctx, license, 72);
        license.addView(aboutRow(ctx, "Activated by",
                (adminName != null && !adminName.trim().isEmpty()) ? adminName.trim() : "unknown"));
        license.addView(aboutRow(ctx, "Key expires",
                (expiryText != null && !expiryText.trim().isEmpty()) ? expiryText.trim() : "unknown"));
        license.addView(aboutRow(ctx, "Devices",
                (deviceText != null && !deviceText.trim().isEmpty()) ? deviceText.trim() : "unknown"));
        page.addView(license);

        page.addView(createSectionLabel(ctx, "COMMUNITY"));
        LinearLayout channelBtn = telegramButton(ctx, "Join Telegram Channel", 13f);
        channelBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openExternalUrl(ctx, channel); }
        });
        page.addView(channelBtn, wideButtonParams(ctx));
        return page;
    }

    private static LinearLayout aboutRow(Context ctx, String label, String value) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(ctx, 4), 0, dp(ctx, 4));
        TextView l = new TextView(ctx);
        l.setText(label);
        l.setTextColor(TEXT_MUTED);
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(l, lp);
        TextView v = new TextView(ctx);
        v.setText(value);
        v.setTextColor(TEXT_WHITE);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        row.addView(v);
        return row;
    }

    private static LinearLayout.LayoutParams wideButtonParams(Context ctx) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 44));
        lp.setMargins(0, dp(ctx, 4), 0, dp(ctx, 4));
        return lp;
    }

    // ------------------------------------------------------------------
    //  Login card
    // ------------------------------------------------------------------

    static Button createLoginActionButton(Context ctx, String text, boolean filledGold) {
        Button btn = new Button(ctx);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, filledGold ? 11.5f : (text.equals("PASTE") ? 11.0f : 10.5f));
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(filledGold ? TEXT_ON_GOLD : GOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(ctx, 10));
        bg.setColor(filledGold ? GOLD : ROW_FILL);
        bg.setStroke(dp(ctx, 1), filledGold ? GOLD : BORDER_GOLD);
        btn.setBackground(bg);
        applyButtonTouchEffect(btn);
        return btn;
    }

    static LinearLayout createLoginContainer(
            Context ctx,
            String initialStatus,
            EditText[] outKeyInput,
            Button[] outPasteBtn,
            Button[] outLoginBtn,
            TextView[] outStatus) {
        return createLoginContainer(
                ctx,
                initialStatus,
                "SERVER ONLINE  •  CARROM POOL",
                "DRAGON ENGINE",
                "CARROM POOL | @" + TG_PERSONAL_FALLBACK,
                TG_CHANNEL_FALLBACK,
                TG_CHANNEL_FALLBACK,
                TG_CHANNEL_FALLBACK,
                outKeyInput,
                outPasteBtn,
                outLoginBtn,
                outStatus);
    }

    static LinearLayout createLoginContainer(
            Context ctx,
            String initialStatus,
            String badgeText,
            String loginTitleText,
            String loginBannerText,
            String buyKeyUrl,
            String freeKeyUrl,
            String telegramUrl,
            EditText[] outKeyInput,
            Button[] outPasteBtn,
            Button[] outLoginBtn,
            TextView[] outStatus) {
        final String safeBadge = (badgeText != null && !badgeText.trim().isEmpty()) ? badgeText : "SERVER ONLINE  •  CARROM POOL";
        final String safeTitle = (loginTitleText != null && !loginTitleText.trim().isEmpty()) ? loginTitleText : "DRAGON ENGINE";
        final String safeBanner = (loginBannerText != null && !loginBannerText.trim().isEmpty()) ? loginBannerText : "CARROM POOL | @" + TG_PERSONAL_FALLBACK;
        final String safeBuyUrl = (buyKeyUrl != null && !buyKeyUrl.trim().isEmpty()) ? buyKeyUrl : TG_CHANNEL_FALLBACK;
        final String safeFreeUrl = (freeKeyUrl != null && !freeKeyUrl.trim().isEmpty()) ? freeKeyUrl : TG_CHANNEL_FALLBACK;
        final String safeTgUrl = (telegramUrl != null && !telegramUrl.trim().isEmpty()) ? telegramUrl : TG_CHANNEL_FALLBACK;
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10));
        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(dp(ctx, 8), dp(ctx, 4), dp(ctx, 8), dp(ctx, 8));
        card.setLayoutParams(cardLp);

        final GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setColor(ROW_FILL);
        cardBg.setCornerRadius(dp(ctx, 16));
        final int strokeW = dp(ctx, 1);
        cardBg.setStroke(strokeW, BORDER_GOLD);
        card.setBackground(cardBg);

        final ValueAnimator borderAnim = ValueAnimator.ofArgb(
                0x66FF7A59, 0xFFFF7A59, 0xFFFF7A59, 0x66FF7A59);
        borderAnim.setDuration(3500);
        borderAnim.setRepeatCount(ValueAnimator.INFINITE);
        borderAnim.addUpdateListener(anim -> cardBg.setStroke(strokeW, (int) anim.getAnimatedValue()));

        final TextView serverPill = new TextView(ctx);
        serverPill.setText(safeBadge);
        serverPill.setTextColor(GOLD);
        serverPill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.0f);
        serverPill.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            serverPill.setLetterSpacing(0.06f);
        }
        serverPill.setGravity(Gravity.CENTER);
        serverPill.setPadding(dp(ctx, 8), dp(ctx, 2), dp(ctx, 8), dp(ctx, 2));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setCornerRadius(dp(ctx, 8));
        pillBg.setColor(0x1AFF7A59);
        pillBg.setStroke(dp(ctx, 1), 0x55FF7A59);
        serverPill.setBackground(pillBg);
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.CENTER_HORIZONTAL;
        pillLp.bottomMargin = dp(ctx, 4);
        serverPill.setLayoutParams(pillLp);
        card.addView(serverPill);

        final ValueAnimator pulseAnim = ValueAnimator.ofFloat(1.0f, 0.55f, 1.0f);
        pulseAnim.setDuration(2200);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.addUpdateListener(anim -> serverPill.setAlpha((float) anim.getAnimatedValue()));

        final TextView authHeader = new TextView(ctx);
        authHeader.setText(safeTitle);
        authHeader.setTextColor(GOLD);
        authHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        authHeader.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            authHeader.setLetterSpacing(0.1f);
        }
        authHeader.setGravity(Gravity.CENTER);
        authHeader.setPadding(0, 0, 0, dp(ctx, 2));
        card.addView(authHeader);

        final ValueAnimator glowAnim = ValueAnimator.ofArgb(GOLD, 0xFFFF9C80, GOLD);
        glowAnim.setDuration(3000);
        glowAnim.setRepeatCount(ValueAnimator.INFINITE);
        glowAnim.addUpdateListener(anim -> {
            int col = (int) anim.getAnimatedValue();
            authHeader.setTextColor(col);
            authHeader.setShadowLayer(8.0f, 0, 0, col);
        });

        card.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                borderAnim.start();
                pulseAnim.start();
                glowAnim.start();
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                borderAnim.cancel();
                pulseAnim.cancel();
                glowAnim.cancel();
            }
        });
        borderAnim.start();
        pulseAnim.start();
        glowAnim.start();

        TextView subTitle = new TextView(ctx);
        subTitle.setText(safeBanner);
        subTitle.setTextColor(GOLD);
        subTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        subTitle.setTypeface(Typeface.DEFAULT_BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            subTitle.setLetterSpacing(0.06f);
        }
        subTitle.setGravity(Gravity.CENTER);
        subTitle.setPadding(0, 0, 0, dp(ctx, 6));
        card.addView(subTitle);

        EditText keyInput = new EditText(ctx);
        keyInput.setHint("Enter License Key...");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        keyInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
        keyInput.setHintTextColor(TEXT_MUTED);
        keyInput.setTextColor(TEXT_WHITE);
        keyInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        keyInput.setSingleLine(true);
        keyInput.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        keyInput.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
        final GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(ctx, 10));
        inputBg.setColor(SURFACE);
        inputBg.setStroke(strokeW, ROW_BORDER);
        keyInput.setBackground(inputBg);
        keyInput.setOnFocusChangeListener((v, hasFocus) ->
                inputBg.setStroke(strokeW, hasFocus ? GOLD : ROW_BORDER));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputLp.bottomMargin = dp(ctx, 8);
        keyInput.setLayoutParams(inputLp);
        card.addView(keyInput);
        if (outKeyInput != null && outKeyInput.length > 0) outKeyInput[0] = keyInput;

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);

        Button pasteBtn = createLoginActionButton(ctx, "PASTE", false);
        LinearLayout.LayoutParams pasteLp = new LinearLayout.LayoutParams(0, dp(ctx, 36), 1.0f);
        pasteLp.rightMargin = dp(ctx, 4);
        pasteBtn.setLayoutParams(pasteLp);
        pasteBtn.setOnClickListener(v -> {
            try {
                ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) {
                    CharSequence pasteData = clipboard.getPrimaryClip().getItemAt(0).getText();
                    if (pasteData != null) {
                        keyInput.setText(pasteData.toString().trim());
                        Toast.makeText(ctx, "Key pasted from clipboard", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ctx, "Clipboard is empty", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(ctx, "Could not access clipboard", Toast.LENGTH_SHORT).show();
            }
        });
        btnRow.addView(pasteBtn);
        if (outPasteBtn != null && outPasteBtn.length > 0) outPasteBtn[0] = pasteBtn;

        Button loginBtn = createLoginActionButton(ctx, "LOGIN", true);
        LinearLayout.LayoutParams loginLp = new LinearLayout.LayoutParams(0, dp(ctx, 36), 1.0f);
        loginLp.leftMargin = dp(ctx, 4);
        loginBtn.setLayoutParams(loginLp);
        btnRow.addView(loginBtn);
        if (outLoginBtn != null && outLoginBtn.length > 0) outLoginBtn[0] = loginBtn;
        card.addView(btnRow);

        Button buyBtn = createLoginActionButton(ctx, "BUY LICENCE KEY", false);
        LinearLayout.LayoutParams buyLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 34));
        buyLp.topMargin = dp(ctx, 6);
        buyBtn.setLayoutParams(buyLp);
        buyBtn.setOnClickListener(v -> openExternalUrl(ctx, safeBuyUrl));
        card.addView(buyBtn);

        Button freeBtn = createLoginActionButton(ctx, "GET FREE KEY", false);
        LinearLayout.LayoutParams freeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 34));
        freeLp.topMargin = dp(ctx, 4);
        freeBtn.setLayoutParams(freeLp);
        freeBtn.setOnClickListener(v -> openExternalUrl(ctx, safeFreeUrl));
        card.addView(freeBtn);

        Button tgBtn = createLoginActionButton(ctx, "JOIN TELEGRAM", false);
        LinearLayout.LayoutParams tgLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 34));
        tgLp.topMargin = dp(ctx, 4);
        tgBtn.setLayoutParams(tgLp);
        tgBtn.setOnClickListener(v -> openExternalUrl(ctx, safeTgUrl));
        card.addView(tgBtn);

        TextView status = new TextView(ctx);
        status.setText(initialStatus);
        status.setTextColor(TEXT_MUTED);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        status.setTypeface(Typeface.MONOSPACE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(ctx, 4), 0, 0);
        if (outStatus != null && outStatus.length > 0) outStatus[0] = status;
        card.addView(status);

        TextView creditLine = new TextView(ctx);
        creditLine.setText(CREDIT_FALLBACK);
        creditLine.setTextColor(0x99FF7A59);
        creditLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        creditLine.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        creditLine.setGravity(Gravity.CENTER);
        creditLine.setPadding(0, dp(ctx, 4), 0, dp(ctx, 2));
        card.addView(creditLine);

        return card;
    }

    static String formatExpiryLabel(String rawExp, boolean[] outExpired) {
        if (outExpired != null && outExpired.length > 0) outExpired[0] = false;
        if (rawExp == null || rawExp.trim().isEmpty()) {
            return "Expiry Active";
        }
        String trimmed = rawExp.trim();
        if (trimmed.equalsIgnoreCase("Lifetime")) {
            return "Expiry Lifetime";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            Date target = sdf.parse(trimmed);
            if (target != null) {
                long diff = target.getTime() - System.currentTimeMillis();
                if (diff <= 0) {
                    if (outExpired != null && outExpired.length > 0) outExpired[0] = true;
                    return "Expiry Expired";
                }
                long sec = (diff / 1000) % 60;
                long min = (diff / (1000 * 60)) % 60;
                long hrs = (diff / (1000 * 60 * 60)) % 24;
                long days = diff / (1000 * 60 * 60 * 24);
                if (days > 0) {
                    return String.format(Locale.US, "Expiry %dd %02dh %02dm %02ds", days, hrs, min, sec);
                }
                return String.format(Locale.US, "Expiry %02dh %02dm %02ds", hrs, min, sec);
            }
        } catch (Exception ignored) { }
        return "Expiry " + trimmed;
    }
}
