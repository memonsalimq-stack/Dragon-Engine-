package com.easyvictory.mods;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * The DRAWING section of the AIM tab: Drawings on/off, line style (Solid, Dash, Dot), thickness and
 * line colour. These settings are applied by the host draw layer in Main.cpp to every line the core
 * draws; they are never sent to the core as feature ids. The values are saved and re-sent on build.
 */
final class EvDrawingPanel {
    interface Listener {
        /** style: 0 Solid, 1 Dash, 2 Dot. thicknessSteps: 0 = as drawn, 1..8. colour: 0 Original, 1 Red, 2 White, 3 Cyan. */
        void onChanged(boolean drawLines, int style, int thicknessSteps, int colour);
    }

    private static final String PREFS = "ev_drawing";
    private static final String[] STYLE_NAMES = {"Solid", "Dash", "Dot"};
    private static final String[] COLOUR_NAMES = {"Original", "Red", "White", "Cyan"};
    private static final int MAX_THICKNESS = 8;

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Listener listener;
    private boolean drawLines;
    private int style;
    private int thickness;
    private int colour;

    private EvDrawingPanel(Context ctx, Listener listener) {
        this.ctx = ctx;
        this.listener = listener;
        this.prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.drawLines = prefs.getBoolean("drawings", true);
        this.style = clamp(prefs.getInt("style", 0), 0, STYLE_NAMES.length - 1);
        this.thickness = clamp(prefs.getInt("thickness", 0), 0, MAX_THICKNESS);
        this.colour = clamp(prefs.getInt("colour", 0), 0, COLOUR_NAMES.length - 1);
    }

    /** Builds the section and immediately sends the saved values to the native layer. */
    static LinearLayout create(Context ctx, Listener listener) {
        EvDrawingPanel panel = new EvDrawingPanel(ctx, listener);
        LinearLayout root = panel.build();
        panel.notifyChanged(false);
        return root;
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private void notifyChanged(boolean save) {
        if (save) {
            prefs.edit().putBoolean("drawings", drawLines).putInt("style", style)
                    .putInt("thickness", thickness).putInt("colour", colour).apply();
        }
        if (listener != null) listener.onChanged(drawLines, style, thickness, colour);
    }

    private LinearLayout build() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);

        // Drawings on/off
        Switch drawings = new Switch(ctx);
        EvIcons.styleSwitchCard(ctx, drawings, "Drawings");
        drawings.setChecked(drawLines);
        drawings.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton button, boolean checked) {
                drawLines = checked;
                notifyChanged(true);
            }
        });
        root.addView(drawings);

        // Line style: three flat cells
        root.addView(segmentedCard("Line style", STYLE_NAMES, style, new IntConsumerLite() {
            @Override public void accept(int index) {
                style = index;
                notifyChanged(true);
            }
        }));

        // Thickness: 0 means "as drawn by the core", 1..8 overrides it
        final LinearLayout thicknessCard = new LinearLayout(ctx);
        thicknessCard.setOrientation(LinearLayout.VERTICAL);
        EvIcons.styleFeatureCard(ctx, thicknessCard, 44);
        final TextView thicknessLabel = new TextView(ctx);
        EvIcons.styleSeekLabel(ctx, thicknessLabel, "Thickness");
        thicknessLabel.setText(thicknessText(thickness));
        thicknessCard.addView(thicknessLabel);
        SeekBar bar = new SeekBar(ctx);
        bar.setFocusable(false);
        bar.setFocusableInTouchMode(false);
        bar.setContentDescription("Line thickness");
        bar.setMax(MAX_THICKNESS);
        bar.setProgress(thickness);
        EvIcons.styleSeekBar(ctx, bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                thicknessLabel.setText(thicknessText(value));
                if (fromUser) {
                    thickness = value;
                    notifyChanged(false);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                thickness = seekBar.getProgress();
                notifyChanged(true);
            }
        });
        thicknessCard.addView(bar);
        root.addView(thicknessCard);

        // Line colour: Original keeps the core's own colours
        root.addView(segmentedCard("Line colour", COLOUR_NAMES, colour, new IntConsumerLite() {
            @Override public void accept(int index) {
                colour = index;
                notifyChanged(true);
            }
        }));
        return root;
    }

    private static String thicknessText(int value) {
        return value <= 0 ? "Thickness: Auto" : "Thickness: " + value;
    }

    /** Java 8 without java.util.function so it also works on API 19. */
    private interface IntConsumerLite {
        void accept(int index);
    }

    private LinearLayout segmentedCard(final String title, final String[] names, int selectedIndex,
                                       final IntConsumerLite onPick) {
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        EvIcons.styleFeatureCard(ctx, card, 44);
        TextView label = new TextView(ctx);
        EvIcons.styleSeekLabel(ctx, label, title);
        label.setText(title);
        label.setPadding(0, 0, 0, EvIcons.dp(ctx, 4));
        card.addView(label);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final Button[] buttons = new Button[names.length];
        final int[] selected = {selectedIndex};
        for (int i = 0; i < names.length; ++i) {
            final int index = i;
            Button button = EvIcons.createChoiceButton(ctx);
            buttons[i] = button;
            EvIcons.styleChoiceButton(ctx, button, i == selected[0], 0, names[i], title);
            button.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    selected[0] = index;
                    for (int j = 0; j < buttons.length; ++j) {
                        EvIcons.styleChoiceButton(ctx, buttons[j], j == index, 0, names[j], title);
                    }
                    onPick.accept(index);
                }
            });
            row.addView(button, EvIcons.createChoiceButtonParams(ctx));
        }
        card.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }
}
