#pragma once
// Pure helpers for the prediction-line style layer (Solid / Dash / Dot, thickness, colour).
// No ImGui, no Android: every function here can be compiled and checked on a desktop compiler.
//
// Coordinates are screen pixels (origin top-left, y down). Colours are ImGui ABGR
// (IM_COL32 layout: A<<24 | B<<16 | G<<8 | R).

#include <cmath>
#include <cstdint>

namespace dragon {

enum LineStyle : int { kLineSolid = 0, kLineDash = 1, kLineDot = 2 };
enum LineColour : int { kColourOriginal = 0, kColourRed = 1, kColourWhite = 2, kColourCyan = 3, kColourYellow = 4 };

constexpr int kMaxThicknessSteps = 8;
constexpr int kMaxPiecesPerLine = 256;  // bounds the work done for one core addLine call

inline int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Slider step (1..8) to pixels. 0 means "keep what the core asked for" and is handled by the caller.
// UNCALIBRATED: one step is about one pixel on a 540 px wide screen and scales with the screen width.
inline float StepsToPixels(int steps, float screenWidthPx) {
    const int s = ClampInt(steps, 1, kMaxThicknessSteps);
    float scale = (std::isfinite(screenWidthPx) && screenWidthPx > 0.0f) ? screenWidthPx / 540.0f : 1.0f;
    if (scale < 1.0f) scale = 1.0f;
    if (scale > 3.0f) scale = 3.0f;
    return static_cast<float>(s) * scale;
}

constexpr uint32_t Abgr(uint32_t r, uint32_t g, uint32_t b, uint32_t a = 255u) {
    return (a << 24) | (b << 16) | (g << 8) | r;
}

// Replaces the RGB part of `original` and keeps its alpha, so fades done by the core still work.
inline uint32_t ApplyColour(uint32_t original, int colour) {
    uint32_t rgb;
    switch (colour) {
        case kColourRed:    rgb = Abgr(255, 59, 48);   break;
        case kColourWhite:  rgb = Abgr(255, 255, 255); break;
        case kColourCyan:   rgb = Abgr(0, 229, 255);   break;
        case kColourYellow: rgb = Abgr(255, 214, 10);  break;
        default: return original;
    }
    return (original & 0xFF000000u) | (rgb & 0x00FFFFFFu);
}

struct PieceSink {
    void* user;
    void (*line)(void* user, float x1, float y1, float x2, float y2);
    void (*dot)(void* user, float cx, float cy, float radius);
};

// Splits one segment into pieces for the chosen style and sends them to `sink`.
// Returns how many pieces were emitted. Solid, an unknown style, a near-zero length or
// non-finite input never subdivides: solid and unknown styles emit the segment unchanged,
// non-finite input emits nothing.
inline int SplitLine(float x1, float y1, float x2, float y2, int style, float thickness, const PieceSink& sink) {
    if (!std::isfinite(x1) || !std::isfinite(y1) || !std::isfinite(x2) || !std::isfinite(y2)) return 0;
    const float dx = x2 - x1;
    const float dy = y2 - y1;
    const float len = std::sqrt(dx * dx + dy * dy);
    if ((style != kLineDash && style != kLineDot) || !(len > 0.5f)) {
        if (sink.line) sink.line(sink.user, x1, y1, x2, y2);
        return sink.line ? 1 : 0;
    }
    const float t = (std::isfinite(thickness) && thickness > 1.0f) ? thickness : 1.0f;
    const float ux = dx / len;
    const float uy = dy / len;

    float dashLen, gapLen;
    if (style == kLineDash) {
        dashLen = 4.0f * t < 8.0f ? 8.0f : 4.0f * t;
        gapLen = 3.0f * t < 6.0f ? 6.0f : 3.0f * t;
    } else {
        dashLen = 0.0f;  // a dot has no length; it is one circle
        gapLen = 3.0f * t < 6.0f ? 6.0f : 3.0f * t;
    }
    float period = dashLen + gapLen;
    // Keep the loop bounded: a very long line with a tiny pattern gets a coarser pattern.
    const float minPeriod = len / static_cast<float>(kMaxPiecesPerLine);
    if (period < minPeriod) {
        const float k = minPeriod / period;
        dashLen *= k;
        gapLen *= k;
        period = minPeriod;
    }

    int emitted = 0;
    if (style == kLineDash) {
        for (float s = 0.0f; s < len && emitted < kMaxPiecesPerLine; s += period) {
            const float e = (s + dashLen < len) ? s + dashLen : len;
            if (sink.line) sink.line(sink.user, x1 + ux * s, y1 + uy * s, x1 + ux * e, y1 + uy * e);
            ++emitted;
        }
    } else {
        const float radius = t * 0.5f < 1.0f ? 1.0f : t * 0.5f;
        for (float s = 0.0f; s <= len && emitted < kMaxPiecesPerLine; s += period) {
            if (sink.dot) sink.dot(sink.user, x1 + ux * s, y1 + uy * s, radius);
            ++emitted;
        }
    }
    return emitted;
}

// ---- Colour detection and remapping (pure helpers; Main.cpp owns the atomics) ----------------------
constexpr int kMaxColourSlots = 8;
constexpr uint32_t kRgbMask = 0x00FFFFFFu;

// Swaps the R and B bytes, converting between ImGui ABGR and Android ARGB. Alpha and G stay put.
constexpr uint32_t SwapRB(uint32_t c) {
    return (c & 0xFF00FF00u) | ((c & 0xFFu) << 16) | ((c >> 16) & 0xFFu);
}

// Returns `col` recoloured through the from/to table (RGB only, alpha kept), or unchanged when no entry matches.
inline uint32_t RemapColour(uint32_t col, const uint32_t* from, const uint32_t* to, int n) {
    for (int i = 0; i < n && i < kMaxColourSlots; ++i) {
        if ((col & kRgbMask) == (from[i] & kRgbMask)) return (col & 0xFF000000u) | (to[i] & kRgbMask);
    }
    return col;
}

// Records the RGB of a visible colour in `table` (capacity `cap`) if it is not there yet.
// Returns the new count. Nearly transparent colours are ignored.
inline int NoteColour(uint32_t* table, int count, int cap, uint32_t col) {
    if ((col >> 24) < 0x40u) return count;
    const uint32_t rgb = col & kRgbMask;
    for (int i = 0; i < count; ++i) {
        if (table[i] == rgb) return count;
    }
    if (count >= cap) return count;
    table[count] = rgb;
    return count + 1;
}

}  // namespace dragon
